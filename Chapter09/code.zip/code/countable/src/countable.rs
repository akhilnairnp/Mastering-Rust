
pub trait Summable {
    fn sum_fields(self) -> usize;
}
