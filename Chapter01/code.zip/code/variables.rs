fn main() {
    let mut target = "world";
    println!("Howdy, {}", target);
    target = "mate";
    println!("Howdy, {}", target);
}
