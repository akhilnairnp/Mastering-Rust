fn main() {
    let condition = true;
    if condition {
        println!("Condition was true");
    } else {
        println!("Condition was false");
    }
}
