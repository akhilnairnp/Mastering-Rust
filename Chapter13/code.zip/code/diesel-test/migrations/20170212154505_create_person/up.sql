CREATE TABLE person (
       id UUID PRIMARY KEY,
       name VARCHAR NOT NULL,
       data JSON
)
