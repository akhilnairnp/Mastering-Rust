fn main() {
    let empty_ok_value = Ok(());
    try!(empty_ok_value);
}
